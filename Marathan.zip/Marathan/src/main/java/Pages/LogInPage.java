package Pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import com.aventstack.extentreports.ExtentTest;

import Base.ProjectSpecMethod;
import io.github.sukgu.Shadow;

public class LogInPage extends ProjectSpecMethod {
	
	public LogInPage(ChromeDriver driver,Shadow shadow,ExtentTest node) {
		this.driver=driver;
		this.shadow=shadow;
		this.node=node;
	}

	public LogInPage userName(String uname) throws IOException {

		try {
			driver.findElement(By.id("user_name")).sendKeys(uname);
			reportStep("username entered succesfully","Pass");
		} catch (Exception e) {
			reportStep( "username not entered succesfully"+e,"Fail");
		}
		
		
		
		return this;
		
	}
	public LogInPage passWord(String pswd) throws IOException {
		try {
			driver.findElement(By.id("user_password")).sendKeys(pswd);
			reportStep("Password entered succesfully","Pass");
		} catch (Exception e) {
			reportStep( "Password not entered succesfully"+e,"Fail");
		}
		
		return this;
	}
	
	public Homepage clickLogin() {
		try {
			
			driver.findElement(By.id("sysverb_login")).click();
			Thread.sleep(8000);
		} 
		catch (Exception e) {
			
		}
		
		return new Homepage(driver, shadow, node);
		
	}
	
}
