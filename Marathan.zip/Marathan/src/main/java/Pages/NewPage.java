package Pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.aventstack.extentreports.ExtentTest;

import Base.ProjectSpecMethod;
import io.github.sukgu.Shadow;

public class NewPage extends ProjectSpecMethod {
	
	public String MobileNumber;
	
	public NewPage(ChromeDriver driver,Shadow shadow,ExtentTest node) {
		this.driver=driver;
		this.shadow=shadow;
		this.node=node;
		
	}
	
	public NewPage enterFName(String fname) throws IOException {
		
		try {
			driver.findElement(By.xpath("//input[@id='sys_user.first_name']")).sendKeys(fname);
			reportStep("FirstName entered succesfully","Pass");
		} catch (Exception e) {
			reportStep( "FirstName not entered "+e,"Fail");
		}
		
		
		return this;
	}
	public NewPage enterLName(String lname) throws IOException {
		
		try {
			driver.findElement(By.id("sys_user.last_name")).sendKeys(lname);
			reportStep("LastName entered succesfully","Pass");
		} catch (Exception e) {
			reportStep( "LastName not entered "+e,"Fail");
		}
		
		
		return this;
	}
	
	public NewPage enterEmail(String mail) throws IOException {
		try {
			driver.findElement(By.id("sys_user.email")).sendKeys(mail);
			reportStep("MailId entered succesfully","Pass");
		} catch (Exception e) {
			reportStep( "MailId not entered "+e,"Fail");
		}
	
		
		return this;
	}
	
	public NewPage enterTitle(String title) throws IOException {
		
		try {
			driver.findElement(By.id("sys_user.title")).sendKeys(title);
			reportStep("Title entered succesfully","Pass");
		} catch (Exception e) {
			reportStep( "Title not entered "+e,"Fail");
		}
		
		
		
		return this;
	}
	public NewPage enterPhone(String ph) throws IOException {
		
		try {
			driver.findElement(By.id("sys_user.phone")).sendKeys(ph);
			reportStep("PhoneNo entered succesfully","Pass");
		} catch (Exception e) {
			reportStep( "PhoneNo not entered "+e,"Fail");
		}
		
		
		return this;
	}
	public NewPage enterMob(String mob) throws IOException {
	
		try {
			driver.findElement(By.id("sys_user.mobile_phone")).sendKeys(mob);
			reportStep("MobNo entered succesfully","Pass");
		} catch (Exception e) {
			reportStep( "MobNo not entered "+e,"Fail");
		}
		
	
		return this;
    }
	
	public NewPage clickSubmitInNew() throws InterruptedException {
		try {
			driver.findElement(By.id("sysverb_insert_bottom")).click();
			Thread.sleep(2000);
			
		} catch (Exception e) {
			
		}
		
		
		return this;
    }
	
	public NewPage enterSearchName() throws InterruptedException {
		
		try {
			WebElement search = driver.findElement(By.xpath("//input[@class='form-control']"));
			Thread.sleep(2000);
			search.clear();
			search.sendKeys("Roshan",Keys.RETURN);
			
		} catch (Exception e) {
			
		}
		
		
		return this;
	}
	
	public NewPage clickIcon() {
		
		try {
			driver.findElement(By.xpath("(//a[contains(@class,'btn btn-icon')])[2]")).click();
			
			
		} catch (Exception e) {
			
		}
		
		return this;
		
	}
	
	public NewPage clickOpenRecord() {
		
		try {
			driver.findElement(By.linkText("Open Record")).click();
			
			
		} catch (Exception e) {
			
		}
		
		return this;
		
	}
	
	public NewPage updatePhoneno() throws IOException {
		
		try {
			WebElement updatePhoneNumber = driver.findElement(By.id("sys_user.phone"));
			updatePhoneNumber.clear();
			updatePhoneNumber.sendKeys("987654321");
			reportStep("Phone no  updated succesfully","Pass");
		} catch (Exception e) {
			reportStep( "Phone no not updated "+e,"Fail");
		}
		
		
		return this;
		
	}
	public NewPage clickUpdateButton() {
		
		try {
			driver.findElement(By.xpath("//button[@id='sysverb_update_bottom']")).click();
			
		} catch (Exception e) {
			
		}
		
		
		return this;
		
	}
	
	public NewPage getMobno() {
		try {
			String mobileNumber = driver.findElement(By.xpath("//input[@id='sys_user.mobile_phone']")).getText();
			System.out.println(mobileNumber);
			MobileNumber=mobileNumber;
			
		} catch (Exception e) {
			
		}
		
		return this;
	}
	
	
	public NewPage clickDelete() {
		try {
			driver.findElement(By.xpath("//button[@id='sysverb_delete_bottom']")).click();
			
			
		} catch (Exception e) {
			
		}
		
		return this;
	}
	public NewPage confirmDelete() throws IOException {
		
		try {
			driver.findElement(By.id("ok_button")).click();
			reportStep("Deleted Succesfully", "Pass");
			
		} catch (Exception e) {
			reportStep("Not Deleted Succesfully"+e, "Fail");
		}
		
		return this;
	}
	
	public NewPage enterSearchMobNo() throws InterruptedException {
		try {
			WebElement search = driver.findElement(By.xpath("//input[@class='form-control']"));
			Thread.sleep(2000);
			search.clear();
			search.sendKeys(MobileNumber,Keys.RETURN);
			
			
		} catch (Exception e) {
			
		}
		
		
		
		return this;
	}
	
	
	
}
