package Pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.aventstack.extentreports.ExtentTest;

import Base.ProjectSpecMethod;
import io.github.sukgu.Shadow;


public class Homepage extends ProjectSpecMethod  {

	public Homepage(ChromeDriver driver,Shadow shadow, ExtentTest node) {
		this.driver=driver;
		this.shadow=shadow;
		this.node=node;
	}
	
	

	public Homepage clickAll() {
		try {
			
			shadow.findElementByXPath("//div[text()='All']").click();
			
		} 
		catch (Exception e) {
			
		}
		
		
		return this;
	}
	
	public Homepage clickFilter() {
		try {
			
			WebElement filter = shadow.findElementByXPath("//input[@id='filter']");
			//shadow.setImplicitWait(10);
			filter.click();
			filter.sendKeys("Callers");
		} 
		catch (Exception e) {
			
		}
	
		return this;
	}
	
	public CallerPage submitName() {
		try {
			
			//shadow.setImplicitWait(10);	
			shadow.findElementByXPath("//span[text()='Callers']").click();
			
		} 
		catch (Exception e) {
			
		}
	
		return new CallerPage(driver, shadow, node);
	}
	
	
}
