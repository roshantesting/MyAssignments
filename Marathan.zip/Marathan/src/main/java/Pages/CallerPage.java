package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.aventstack.extentreports.ExtentTest;

import Base.ProjectSpecMethod;
import io.github.sukgu.Shadow;

public class CallerPage extends ProjectSpecMethod {

	public CallerPage(ChromeDriver driver,Shadow shadow,ExtentTest node) {
		this.driver=driver;
		this.shadow=shadow;
		this.node=node;
	}
	
	
	public NewPage switchFrame() throws InterruptedException {
		Thread.sleep(2000);
		WebElement eleFrame = shadow.findElementByXPath("//iframe[@id='gsft_main']");
		driver.switchTo().frame(eleFrame);
		return new NewPage(driver, shadow, node);
	}
	
	
	public NewPage clickNew() throws InterruptedException {
		
		try {
			
			Thread.sleep(2000);
			WebElement eleFrame = shadow.findElementByXPath("//iframe[@id='gsft_main']");
			driver.switchTo().frame(eleFrame);
			driver.findElement(By.xpath("//button[@id='sysverb_new']")).click();
		} 
		catch (Exception e) {
			
		}
	
		return new NewPage(driver, shadow, node);
	}
	
	
	
	
	
}
