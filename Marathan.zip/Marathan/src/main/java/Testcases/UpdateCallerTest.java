package Testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Base.ProjectSpecMethod;
import Pages.LogInPage;

public class UpdateCallerTest extends ProjectSpecMethod {
	
	
	@BeforeTest
    public void setup() {
		//excelfile="CreateLead";
		testName="CreateCaller";
        testDescription="Service Now";
        testCategory="smoke";
        testAuthor="Roshan";
        
        
    }
	
	@Test(dataProvider = "fetchData")
	public void runUpdateCallertest(String uname,String pswd, String fname,String lname,String mail,String title,String mob,String ph) throws InterruptedException, IOException {
		
		LogInPage lp=new LogInPage(driver,shadow, node);
		lp.userName(uname)
		.passWord(pswd)
		.clickLogin()
		.clickAll()
		.clickFilter()
		.submitName()
		.switchFrame()
		.enterSearchName()
		.clickIcon()
		.clickOpenRecord()
		.updatePhoneno()
		.clickUpdateButton();
		
		
		
	}
	
	

}
